import os
import joblib

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor

from preprocess import tai_va_xu_ly_du_lieu

(
    X_train,
    X_test,
    y_train,
    y_test,
    scaler,
    feature_names
) = tai_va_xu_ly_du_lieu("../data/nha_viet_nam.csv")

print("\n===== TRAIN MODEL =====")

model = XGBRegressor(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=5,
    random_state=42
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print("\n===== KẾT QUẢ =====")
print("MAE:", mean_absolute_error(y_test, pred))
print("MSE:", mean_squared_error(y_test, pred))
print("R2 SCORE:", r2_score(y_test, pred))

os.makedirs("../models", exist_ok=True)

joblib.dump(model, "../models/model.pkl")
joblib.dump(scaler, "../models/scaler.pkl")
joblib.dump(feature_names.tolist(), "../models/features.pkl")

print("\nLƯU MODEL THÀNH CÔNG")
