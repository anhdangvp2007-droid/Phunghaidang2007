import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("../data/nha_viet_nam.csv")

print(df.describe())

plt.figure(figsize=(12, 8))

numeric_df = df.select_dtypes(include=["number"])

sns.heatmap(
    numeric_df.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title("Ma trận tương quan")
plt.show()

plt.figure(figsize=(10, 6))

sns.histplot(df["gia_nha"], kde=True)

plt.title("Phân phối giá nhà")
plt.show()

plt.figure(figsize=(10, 6))

sns.scatterplot(
    x=df["dien_tich"],
    y=df["gia_nha"]
)

plt.title("Diện tích và giá nhà")
plt.show()
