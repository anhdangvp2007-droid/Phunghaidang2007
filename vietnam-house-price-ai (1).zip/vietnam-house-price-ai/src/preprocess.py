import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def tai_va_xu_ly_du_lieu(path):
    df = pd.read_csv(path)

    print("\n===== 5 DÒNG ĐẦU =====")
    print(df.head())

    print("\n===== THÔNG TIN DỮ LIỆU =====")
    print(df.info())

    # One-hot encoding cho quận
    df = pd.get_dummies(df, columns=["quan"])

    X = df.drop("gia_nha", axis=1)
    y = df["gia_nha"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    scaler = StandardScaler()

    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return (
        X_train_scaled,
        X_test_scaled,
        y_train,
        y_test,
        scaler,
        X.columns
    )
