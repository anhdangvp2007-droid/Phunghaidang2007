# AI Dự Đoán Giá Nhà Việt Nam

## Cài thư viện
pip install -r requirements.txt

## Train model
cd src
python train.py

## Chạy web
cd ..
streamlit run app.py
